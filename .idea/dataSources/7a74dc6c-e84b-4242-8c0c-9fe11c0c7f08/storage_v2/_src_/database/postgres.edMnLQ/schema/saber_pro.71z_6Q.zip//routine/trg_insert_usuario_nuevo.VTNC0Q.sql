create function trg_insert_usuario_nuevo() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO saber_pro.usuarionuevo (id_user)
    VALUES (NEW.id_user)
    ON CONFLICT (id_user) DO NOTHING;  -- evita duplicados
    RETURN NEW;
END;
$$;

alter function trg_insert_usuario_nuevo() owner to postgres;

